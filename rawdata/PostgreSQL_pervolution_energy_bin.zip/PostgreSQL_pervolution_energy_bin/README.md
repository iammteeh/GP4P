# PostgreSQL (pervolution, energy) – discretized

Discretized results from [PostgreSQL_pervolution_energy](../PostgreSQL_pervolution_energy).

The following numeric options are represented by binary options:
- **sharedBuffers** with values 64, 128, 256
- **tempBuffers** with values 2, 8, 32
- **workMem** with values 256, 1024, 4096

Used 11.2 for energy