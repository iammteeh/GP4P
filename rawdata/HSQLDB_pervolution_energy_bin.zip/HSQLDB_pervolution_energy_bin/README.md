# HSQLDB (pervolution, energy) – discretized

Discretized results from [HSQLDB_pervolution_energy](../HSQLDB_pervolution_energy).

The following numeric options are represented by binary options:
- **cacheSize** with values 625, 2500, 10000
- **defragLimit** with values 10, 50, 100
- **logSize** with values 0, 5, 50, 100
