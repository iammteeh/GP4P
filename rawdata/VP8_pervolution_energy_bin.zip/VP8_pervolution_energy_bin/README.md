# VP8 (pervolution, energy) – discretized

Discretized results from [VP8_pervolution_energy](../VP8_pervolution_energy).

The following numeric options are represented by binary options:
- **threads** with values 1, 2, 3, 4
- **tokenParts** with values 0, 1, 2
- **arnrMaxFrames** with values 0, 5, 15
- **arnrStrength** with values 0, 3, 6

used 1.8.0 for energy